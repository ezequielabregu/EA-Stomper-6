#include <Arduino.h>
#include <MIDI.h>
#include <Bounce2.h> // Librería para debounce

MIDI_CREATE_DEFAULT_INSTANCE();

const int ledPins[] = {37, 35, 33, 31, 23, 25, 27, 29};
const int buttonPins[] = {36, 34, 32, 30, 22, 24, 26, 28};
int ctrlDefaults[] = {100, 101, 102, 103, 104, 105, 106, 107};
int ctrl[8];

int midiChannel = 1;

Bounce buttonBounce[8];

void setup() {
    Serial.begin(31250);
    MIDI.begin(1);

    for (int i = 0; i < 8; i++) {
        pinMode(ledPins[i], OUTPUT);
        pinMode(buttonPins[i], INPUT_PULLUP);
        ctrl[i] = ctrlDefaults[i];

        buttonBounce[i].attach(buttonPins[i]);
        buttonBounce[i].interval(10); // 10 ms de debounce

        // Inicializa LEDs apagados
        digitalWrite(ledPins[i], LOW);
    }
}

void loop() {
    // Actualiza el estado de los botones con debounce
    for (int i = 0; i < 8; i++) {
        buttonBounce[i].update();
        if (buttonBounce[i].fell()) { // Detecta pulsación
            digitalWrite(ledPins[i], HIGH);
            MIDI.sendControlChange(ctrl[i], 127, midiChannel);
        } 
        if (buttonBounce[i].rose()) { // Detecta liberación
            digitalWrite(ledPins[i], LOW);
            MIDI.sendControlChange(ctrl[i], 0, midiChannel);
        }
    }
}